#include<stdio.h>
main()
{
	int valor;
	printf("informe um valor:\n");
	scanf("%d", &valor);
	printf("O dobro do valor digitado é: %d\n", valor*2);
}
