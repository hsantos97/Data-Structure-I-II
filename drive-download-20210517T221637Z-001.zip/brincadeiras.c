#include<stdio.h>

int main()
{
	char a, b;
	
	a = 'A';
	b = 'B';
	
	if( a > b )
		printf("%c\n", a);
	else
		printf("%c\n", b);
	
	return 1;
}
